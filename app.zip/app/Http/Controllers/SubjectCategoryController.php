<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreSubjectCategoryRequest;
use App\Http\Requests\UpdateSubjectCategoryRequest;
use App\Models\SubjectCategory;

class SubjectCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreSubjectCategoryRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(SubjectCategory $subjectCategory)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(SubjectCategory $subjectCategory)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateSubjectCategoryRequest $request, SubjectCategory $subjectCategory)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(SubjectCategory $subjectCategory)
    {
        //
    }
}
