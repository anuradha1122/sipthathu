<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreSchoolDensityRequest;
use App\Http\Requests\UpdateSchoolDensityRequest;
use App\Models\SchoolDensity;

class SchoolDensityController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreSchoolDensityRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(SchoolDensity $schoolDensity)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(SchoolDensity $schoolDensity)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateSchoolDensityRequest $request, SchoolDensity $schoolDensity)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(SchoolDensity $schoolDensity)
    {
        //
    }
}
