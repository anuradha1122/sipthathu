<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreCircularSubjectRequest;
use App\Http\Requests\UpdateCircularSubjectRequest;
use App\Models\CircularSubject;

class CircularSubjectController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreCircularSubjectRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(CircularSubject $circularSubject)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(CircularSubject $circularSubject)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateCircularSubjectRequest $request, CircularSubject $circularSubject)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(CircularSubject $circularSubject)
    {
        //
    }
}
