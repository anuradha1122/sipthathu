<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreWorkPlaceRequest;
use App\Http\Requests\UpdateWorkPlaceRequest;
use App\Models\WorkPlace;

class WorkPlaceController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreWorkPlaceRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(WorkPlace $workPlace)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(WorkPlace $workPlace)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateWorkPlaceRequest $request, WorkPlace $workPlace)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(WorkPlace $workPlace)
    {
        //
    }
}
