<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreCenterTypeRequest;
use App\Http\Requests\UpdateCenterTypeRequest;
use App\Models\CenterType;

class CenterTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreCenterTypeRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(CenterType $centerType)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(CenterType $centerType)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateCenterTypeRequest $request, CenterType $centerType)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(CenterType $centerType)
    {
        //
    }
}
