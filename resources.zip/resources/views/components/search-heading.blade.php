<div class="px-4 sm:px-4">
    <h3 class="text-base font-semibold leading-7 text-gray-900">{{ $heading }}</h3>
    <p class="mt-1 max-w-2xl text-sm leading-6 text-gray-500">{{ $subheading }}</p>
</div>
