<div>
    <dt class="text-sm font-medium text-gray-500">
        {{ $heading }}
    </dt>
</div>