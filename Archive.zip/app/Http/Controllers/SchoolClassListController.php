<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreSchoolClassListRequest;
use App\Http\Requests\UpdateSchoolClassListRequest;
use App\Models\SchoolClassList;

class SchoolClassListController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreSchoolClassListRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(SchoolClassList $schoolClassList)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(SchoolClassList $schoolClassList)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateSchoolClassListRequest $request, SchoolClassList $schoolClassList)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(SchoolClassList $schoolClassList)
    {
        //
    }
}
