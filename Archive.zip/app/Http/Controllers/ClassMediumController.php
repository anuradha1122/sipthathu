<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreClassMediumRequest;
use App\Http\Requests\UpdateClassMediumRequest;
use App\Models\ClassMedium;

class ClassMediumController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreClassMediumRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(ClassMedium $classMedium)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(ClassMedium $classMedium)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateClassMediumRequest $request, ClassMedium $classMedium)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(ClassMedium $classMedium)
    {
        //
    }
}
