<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreeducationQualificationTypeRequest;
use App\Http\Requests\UpdateeducationQualificationTypeRequest;
use App\Models\educationQualificationType;

class EducationQualificationTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreeducationQualificationTypeRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(educationQualificationType $educationQualificationType)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(educationQualificationType $educationQualificationType)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateeducationQualificationTypeRequest $request, educationQualificationType $educationQualificationType)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(educationQualificationType $educationQualificationType)
    {
        //
    }
}
